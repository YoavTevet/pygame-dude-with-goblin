import pygame
import os

pygame.init()

win = pygame.display.set_mode((500, 480))
pygame.display.set_caption("A game")

score = 0
shot_count = 0

current_path = os.path.dirname(__file__)  # for some reason necessary for the image locations

walk_right = [pygame.image.load(os.path.join(current_path, 'R1.png')),
              pygame.image.load(os.path.join(current_path, 'R2.png')),
              pygame.image.load(os.path.join(current_path, 'R3.png')),
              pygame.image.load(os.path.join(current_path, 'R4.png')),
              pygame.image.load(os.path.join(current_path, 'R5.png')),
              pygame.image.load(os.path.join(current_path, 'R6.png')),
              pygame.image.load(os.path.join(current_path, 'R7.png')),
              pygame.image.load(os.path.join(current_path, 'R8.png')),
              pygame.image.load(os.path.join(current_path, 'R9.png'))]

walk_left = [pygame.image.load(os.path.join(current_path, 'L1.png')),
             pygame.image.load(os.path.join(current_path, 'L2.png')),
             pygame.image.load(os.path.join(current_path, 'L3.png')),
             pygame.image.load(os.path.join(current_path, 'L4.png')),
             pygame.image.load(os.path.join(current_path, 'L5.png')),
             pygame.image.load(os.path.join(current_path, 'L6.png')),
             pygame.image.load(os.path.join(current_path, 'L7.png')),
             pygame.image.load(os.path.join(current_path, 'L8.png')),
             pygame.image.load(os.path.join(current_path, 'L9.png'))]

bg = pygame.image.load(os.path.join(current_path, 'bg.jpg'))  # background
char = pygame.image.load(os.path.join(current_path, 'standing.png'))  # standing still

clock = pygame.time.Clock()

bullet_sound = pygame.mixer.Sound(os.path.join(current_path, 'stomp.wav'))
hit_sound = pygame.mixer.Sound(os.path.join(current_path, 'fireworks - Copy (online-audio-converter.com).wav'))
music = pygame.mixer.music.load(os.path.join(current_path, 'music.mp3'))
# pygame.mixer.music.play(-1)


class Player:
    def __init__(self, x, y, width, height):
        self.x = x
        self.y = y
        self.width = width
        self.height = height
        self.vel = 5
        self.is_jump = False
        self.jump_count = 10
        self.left = False
        self.right = False
        self.walk_count = 0
        self.standing = True
        self.hit_box = (self.x + 17, self.y + 11, 29, 52)

    def draw(self, wn):  # wn is like win, its the window the program is running on.
        if self.walk_count + 1 >= 27:
            self.walk_count = 0

        if not self.standing:
            if self.left:
                wn.blit(walk_left[self.walk_count // 3], (self.x, self.y))
                self.walk_count += 1
            elif self.right:
                wn.blit(walk_right[self.walk_count // 3], (self.x, self.y))
                self.walk_count += 1
        else:
            if self.right:
                wn.blit(walk_right[0], (self.x, self.y))
            else:
                wn.blit(walk_left[0], (self.x, self.y))
        self.hit_box = (self.x + 17, self.y + 11, 29, 52)
        # pygame.draw.rect(wn, (0, 0, 255), self.hit_box, 2)  # a rectangle around the character. only used for dev

    def hit(self):
        self.x = 20
        self.y = 420
        self.walk_count = 0
        font1 = pygame.font.SysFont('arial', 100)
        text = font1.render('-5', 1, (255, 0, 0))
        win.blit(text, (250 - (text.get_width() / 2), 200))
        pygame.display.update()
        i = 0
        while i < 100:
            pygame.time.delay(10)
            i += 1
            for even in pygame.event.get():
                if even.type == pygame.QUIT:
                    i = 101
                    pygame.quit()
        if goblin.health + 5 < 10:
            goblin.health += 5
        else:
            goblin.health = 10


class Enemy:
    walkRight = [pygame.image.load(os.path.join(current_path, 'R1E.png')),
                 pygame.image.load(os.path.join(current_path, 'R2E.png')),
                 pygame.image.load(os.path.join(current_path, 'R3E.png')),
                 pygame.image.load(os.path.join(current_path, 'R4E.png')),
                 pygame.image.load(os.path.join(current_path, 'R5E.png')),
                 pygame.image.load(os.path.join(current_path, 'R6E.png')),
                 pygame.image.load(os.path.join(current_path, 'R7E.png')),
                 pygame.image.load(os.path.join(current_path, 'R8E.png')),
                 pygame.image.load(os.path.join(current_path, 'R9E.png')),
                 pygame.image.load(os.path.join(current_path, 'R10E.png')),
                 pygame.image.load(os.path.join(current_path, 'R11E.png'))]
    walkLeft = [pygame.image.load(os.path.join(current_path, 'L1E.png')),
                pygame.image.load(os.path.join(current_path, 'L2E.png')),
                pygame.image.load(os.path.join(current_path, 'L3E.png')),
                pygame.image.load(os.path.join(current_path, 'L4E.png')),
                pygame.image.load(os.path.join(current_path, 'L5E.png')),
                pygame.image.load(os.path.join(current_path, 'L6E.png')),
                pygame.image.load(os.path.join(current_path, 'L7E.png')),
                pygame.image.load(os.path.join(current_path, 'L8E.png')),
                pygame.image.load(os.path.join(current_path, 'L9E.png')),
                pygame.image.load(os.path.join(current_path, 'L10E.png')),
                pygame.image.load(os.path.join(current_path, 'L11E.png'))]

    def __init__(self, x, y, width, height, end):
        self.x = x
        self.y = y
        self.width = width
        self.height = height
        self.end = end
        self.path = [self.x, self.end]
        self.walk_count = 0
        self.vel = 3
        self.hit_box = (self.x + 17, self.y + 2, 31, 57)
        self.health = 10
        self.visible = True

    def draw(self, wn):
        self.move()
        if self.visible:
            if self.walk_count + 1 >= 33:
                self.walk_count = 0

            if self.vel > 0:
                wn.blit(self.walkRight[self.walk_count // 3], (self.x, self.y))
                self.walk_count += 1
            else:
                wn.blit(self.walkLeft[self.walk_count // 3], (self.x, self.y))
                self.walk_count += 1
            pygame.draw.rect(wn, (255, 0, 0), (self.hit_box[0], self.hit_box[1] - 20, 50, 10))
            pygame.draw.rect(wn, (0, 255, 0), (self.hit_box[0], self.hit_box[1] - 20, 50 + (self.health - 10) * 5, 10))
            self.hit_box = (self.x + 17, self.y + 2, 31, 57)
        # pygame.draw.rect(wn, (0, 0, 255), self.hit_box, 2)  # rectangle around the character. used for dev

    def move(self):
        if self.vel > 0:  # if moving right
            if self.x + self.vel < self.path[1]:  # makes sure the enemy hasn't exceeded its move limit (self.end)
                self.x += self.vel
            else:
                self.vel *= -1
                self.walk_count = 0
        else:  # moving left
            if self.x - self.vel > self.path[0]:
                self.x += self.vel
            else:
                self.vel *= -1
                self.walk_count = 0

    def hit(self):
        global shot_count
        if self.health > 0:  # if alive
            self.health -= 1
        else:  # not alive
            self.visible = False
            self.vel = 0
        shot_count += 1
        hit_sound.play()
        print('hit {}'.format(shot_count))


class Projectile:
    def __init__(self, x, y, radius, color, facing):
        self.x = x
        self.y = y
        self.radius = radius
        self.color = color
        self.facing = facing
        self.vel = 8 * facing

    def draw(self, wn):  # wn in like win, the window the program is running on.
        pygame.draw.circle(wn, self.color, (self.x, self.y), self.radius)


def redrawGameWindow():  # contains all the things to redraw every time the main loop occurs.
    global man
    text = font.render('score: {}'.format(score), 1, (0, 0, 0))
    win.blit(bg, (0, 0))
    win.blit(text, (370, 10))  # score bar
    man.draw(win)
    goblin.draw(win)
    for x in bullets:
        x.draw(win)

    pygame.display.update()


font = pygame.font.SysFont('arial', size=30, bold=True)
man = Player(30, 420, 64, 64)
goblin = Enemy(100, 420, 64, 64, 450)
bullets = []
shoot = 0
run = True
# main game loop
while run:
    clock.tick(54)  # game should happen 27 times per second, but its not smooth enough for me.

    if man.hit_box[1] < goblin.hit_box[1] + goblin.hit_box[3] and \
            man.hit_box[1] + man.hit_box[3] > goblin.hit_box[1]:
        # if within the x coordinates
        if man.hit_box[0] + man.hit_box[2] > goblin.hit_box[0] and \
                man.hit_box[0] < goblin.hit_box[0] + goblin.hit_box[2]:
            if goblin.visible:
                man.hit()
                score -= 5

    if shoot >= 0:
        shoot += 1
    if shoot > 6:
        shoot = 0

    for event in pygame.event.get():  # doesn't throw an error / crashes the computer when we hit the X button.
        if event.type == pygame.QUIT:
            run = False
            break

    for bullet in bullets:
        # if within the y coordinates
        if bullet.y - bullet.radius < goblin.hit_box[1] + goblin.hit_box[3] and \
                bullet.y + bullet.radius > goblin.hit_box[1]:
            # if within the x coordinates
            if bullet.x + bullet.radius > goblin.hit_box[0] and \
                    bullet.x - bullet.radius < goblin.hit_box[0] + goblin.hit_box[2]:
                if goblin.visible:
                    goblin.hit()
                    score += 1
                if goblin.visible:
                    bullets.pop(bullets.index(bullet))
        # moves bullets inside the screen and destroys the ones that are out.
        if 0 < bullet.x < 500:
            bullet.x += bullet.vel
        else:
            bullets.pop(bullets.index(bullet))

    keys = pygame.key.get_pressed()

    if keys[pygame.K_SPACE] and shoot == 0:  # space for shoot.
        if man.left:
            d = -1
        else:
            d = 1
        if len(bullets) < 5:
            bullets.append(Projectile(round(man.x + man.width // 2), round(man.y + man.height // 2), 6, (255, 0, 0), d))
            bullet_sound.play()

    if keys[pygame.K_LEFT]:
        man.x -= man.vel
        man.left = True
        man.right = False
        man.standing = False
    elif keys[pygame.K_RIGHT]:
        man.x += man.vel
        man.right = True
        man.left = False
        man.standing = False
    else:
        man.walk_count = 0
        man.standing = True

    if not man.is_jump:  # we can move left and right during the jump, but not up and down.
        if keys[pygame.K_UP]:
            man.is_jump = True
            # man.right = False
            # man.left = False
            man.walk_count = 0
    else:
        if man.jump_count >= -10:
            neg = 1  # required because negative values ** 2 are positive, so we want to change them back to go down.
            if man.jump_count < 0:
                neg = -1
            man.y -= (man.jump_count ** 2) * 0.3 * neg
            man.jump_count -= 1
        else:
            man.is_jump = False
            man.jump_count = 10

    if keys[pygame.K_0] and not goblin.visible:
        goblin.health = 10
        goblin.visible = True
        goblin.walk_count = 0
        goblin.vel = 3
        man.x = 50
        man.y = 420

    if 0 > man.x:
        man.x = 0
    if 0 > man.y:
        man.y = 0

    # in order to keep the object's entire "body" inside the screen, we use the "body's" dimensions.
    if 500 - man.width < man.x:
        man.x = 500 - man.width
    if 480 - man.height < man.y:
        man.y = 480 - man.height

    redrawGameWindow()

pygame.quit()
